//
//  InitialSlidingViewController.h
//  ECSlidingViewController
//
//  Created by Mahesh Kumar Dhakad on 12/23/12.
//  Copyright (c) 2012 MKD. All rights reserved.
//

#import "MDSlidingViewController.h"

@interface InitialSlidingViewController : MDSlidingViewController

@end
