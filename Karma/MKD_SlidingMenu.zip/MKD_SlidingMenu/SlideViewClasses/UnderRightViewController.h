//
//  UnderRightViewController.h
//  ECSlidingViewController
//
//  Created by Michael Enriquez on 1/23/12.
//  Copyright (c) 2012 EdgeCase. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MDSlidingViewController.h"

@interface UnderRightViewController : UIViewController

@property (nonatomic, retain) IBOutlet UIImageView *imgView_Profile;
@property (nonatomic, retain) IBOutlet UILabel *lbl_ProfileName;

@end
